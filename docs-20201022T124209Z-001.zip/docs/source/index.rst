.. Communication platform documentation master file, created by
   sphinx-quickstart on Thu Sep 17 11:16:20 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.
   
############################################################
Welcome to Group J:s Communication platform's documentation!
############################################################


Contents:
*********

.. toctree::
   :maxdepth: 2

   intro
   documentation

Indices and tables
******************

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
