## uu-game
uu-game for software engineering and project management course

## How to use

- To run the game engine:

`python -m game_engine`

- To run tests:

`python -m unitteest`

- AI simulation:

`config.json` contains something like:
```json
    "simulation_game_file_path": "simulation_game.json",
    "simulation": {
        "ai_diffculty_1": "easy",
        "ai_diffculty_2": "medium",
        "turns": "1000"
    }
```
where `ai\_difficulty\_#` are the difficulties of both AIs and turns represent the
number of turns it's going to be simulated for. Note that `ai\_difficulty\_1` will
always take the first turn.

The simulation will be using a game file (path `simulation_game_file_path`), since it
will include information regarding previous actions for both players. This
information is crucial to make sure that the AI will make a valid move.

`python -m  game_engine simulate`

## Misc

A class diagram is available `class_diagram.puml` which utilizes [plantuml](https://plantuml.com/)
