from game_engine.utils.config import config
from game_engine.utils.ai_simulation import run_simulation
from game_engine.file_parser import file_parser
from game_engine.minimax import minimax
from game_engine.game import game
import sys

GAME_FILE = "game.json"


def main():
    my_file_parser = file_parser(config().get('game_file_path'))
    my_game = game(
        turn=my_file_parser.get_turn(),
        game_board=my_file_parser.get_game_board(),
        curr_player=my_file_parser.get_player_to_move(),
        last_action=my_file_parser.get_last_action_for_player(
            my_file_parser.get_player_to_move()),
    )

    my_minimax = minimax(my_file_parser.get_difficulty())
    action = my_minimax.get_action(my_game)
    my_game.make_action(action)

    if (config().get('logging')):
        print('player: ', config().get('board_signs')
              [my_game.get_previous_player_to_move()])
        print('points: ', my_minimax._points)
        print('action: ', action)
        print(my_game, "\n")

    my_file_parser.write_game_file(my_game, my_file_parser.get_difficulty())


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'simulate':
        run_simulation()
    else:
        main()
