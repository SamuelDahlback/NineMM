import unittest
from unittest import TestCase
from game_engine.game import game
from game_engine.minimax import minimax
from game_engine.difficulty import difficulty


class test_ai(TestCase):

    def parse_game_board_text(self, game_board_text):
        return[list(row) for row in game_board_text]

    def test_win_move(self):
        """
        test if the ai will make the winning move
        """
        game_near_won = [
            "O-----#-----#",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "#-#-#   #-O-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---X---# |",
            "|-    |    -|",
            "X-----#-----X"
        ]

        game_near_won = game(50, self.parse_game_board_text(game_near_won),
                             'player1')
        my_minimax = minimax(difficulty.EASY)
        expected_action = {
            'from': [10, 6],
            'to': [12, 6],
        }
        action = my_minimax.get_action(game_near_won)

        assert(
            action['from'] == expected_action['from']
            and action['to'] == expected_action['to']
            and 'remove' in action)

    def test_block_winning_move(self):
        """
        test if the ai will block the winning move for the enemy
        """

        game_near_won = [
            "O-----#-----#",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "#-#-#   #-O-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---X---# |",
            "|-    |    -|",
            "X-----#-----X"
        ]

        game_near_won = game(51, self.parse_game_board_text(game_near_won),
                             'player2')
        my_minimax = minimax(difficulty.MEDIUM)
        expected_action = {
            'from': [0, 0],
            'to': [12, 6],
        }
        action = my_minimax.get_action(game_near_won)

        self.assertEqual(action['to'], expected_action['to'])

    def test_win_move_limiting_enemy_moves(self):
        """
        test if the ai will make the winning move
        """
        game_near_won = [
            "O-----O-----X",
            "|-    |    -|",
            "| O---O---X |",
            "| |-  |  -| |",
            "| | X-X-# | |",
            "| | |   | | |",
            "O-X-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| X---X---# |",
            "|-    |    -|",
            "#-----#-----X"
        ]

        game_near_won = game(50, self.parse_game_board_text(game_near_won),
                             'player1')
        my_minimax = minimax(difficulty.MEDIUM)
        expected_action = {
            'from': [10, 2],
            'to': [12, 0],
        }
        action = my_minimax.get_action(game_near_won)

        self.assertEqual(expected_action, action)

    def test_forming_2_adjacent(self):
        """
        test if the ai will make the winning move
        """

        game_board = [
            "#-----#-----#",
            "|-    |    -|",
            "| O---#---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "X-#-#   #-O-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "#-----X-----#"
        ]

        my_game = game(4, self.parse_game_board_text(game_board), 'player1')
        my_minimax = minimax(difficulty.MEDIUM)

        expected_action = {
            'to': [12, 0],
        }
        action = my_minimax.get_action(my_game)
        my_game.make_action(action)

        self.assertEqual(expected_action, action)


if __name__ == '__main__':
    unittest.main()
