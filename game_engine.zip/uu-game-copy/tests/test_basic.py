import unittest
from unittest import TestCase
from game_engine.game import game
from game_engine.utils.config import config
from game_engine.difficulty import difficulty
from game_engine.file_parser import file_parser


class FileParserTest(TestCase):

    def test_valid_game_json(self):
        """
        check the positions where you can place on or move to a peice
        """
        my_file_parser = file_parser(config().get('game_file_path'))
        assert(type(my_file_parser.get_turn()) is int)
        assert(type(my_file_parser.get_difficulty()) is difficulty)
        assert(type(my_file_parser.get_game_board()) is list)

    def test_invalid_game_board(self):
        my_file_parser = file_parser(
            'tests/game_file_examples/invalid_game_board.json')

        with self.assertRaises(SystemExit) as cm:
            my_file_parser.get_game_board()

        self.assertEqual(cm.exception.code, 1)

    def test_write_game_file(self):
        my_file_parser = file_parser(config().get('game_file_path'))
        curr_game = game(
            turn=my_file_parser.get_turn(),
            game_board=my_file_parser.get_game_board(),
            curr_player=my_file_parser.get_player_to_move(),
        )
        my_file_parser.write_game_file(
            curr_game, my_file_parser.get_difficulty())
        another_file_parser = file_parser(config().get('game_file_path'))
        another_game = game(
            turn=another_file_parser.get_turn(),
            game_board=another_file_parser.get_game_board(),
            curr_player=my_file_parser.get_player_to_move(),
        )

        self.assertEqual(curr_game, another_game)


class GameTest(TestCase):

    def parse_game_board_text(self, game_board_text):
        return [list(row) for row in game_board_text]

    def test_not_finished_game_phase_1(self):
        """
        at phase one, a player can have less than 3 pieces without the game finishing
        """

        game_board_finished = [
            "O-----#-----#",
            "|-    |    -|",
            "| #---#---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "#-#-#   #-O-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "X-----X-----X"
        ]

        game_finished = game(
            5, self.parse_game_board_text(game_board_finished), 'player1')
        assert(not game_finished.is_finished())

    def test_not_finished_game_phase_2(self):
        """
        at phase 2, a game is not finished when no player has less than 3 pieces
        """
        game_board_not_finished = [
            "O-----O-----#",
            "|-    |    -|",
            "| #---#---O |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "#-#-#   #-O-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---X |",
            "|-    |    -|",
            "X-----X-----X"
        ]

        game_not_finished = game(
            45, self.parse_game_board_text(game_board_not_finished), 'player1')
        assert(not game_not_finished.is_finished())

    def test_finished_game_phase_2_no_moves(self):
        """
        at phase 2, a game is finished when player has no legal moves
        """
        game_finished = [
            "O-----O-----X",
            "|-    |    -|",
            "| O---O---X |",
            "| |-  |  -| |",
            "| | X-X-# | |",
            "| | |   | | |",
            "X-X-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---X---# |",
            "|-    |    -|",
            "#-----#-----X"
        ]

        game_finished = game(
            45, self.parse_game_board_text(game_finished), 'player2')
        assert(game_finished.is_finished())

    def test_finished_game(self):
        """
        at phase 2, a game is finished when a player has less than 3 pieces
        """

        game_board_finished = [
            "O-----#-----#",
            "|-    |    -|",
            "| #---#---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "#-#-#   #-O-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "X-----X-----X"
        ]
        game_finished = game(
            49, self.parse_game_board_text(game_board_finished), 'player1')

        assert(game_finished.is_finished())
        assert(game_finished.get_winner() == 'player1')

    def test_two_adjacent_pieces_for_player(self):
        """
        check the positions where you can place on or move to a piece
        """
        game_board = [
            "X-----X-----#",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "O-#-#   #-#-X",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "O-----#-----X"
        ]
        my_game = game(50, self.parse_game_board_text(game_board), 'player1')
        num_rows = 2

        self.assertEqual(
            my_game.get_two_adjacent_pieces_for_player('player1'), num_rows)

        game_board = [
            "#-----#-----#",
            "|-    |    -|",
            "| #---O---O |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "X-#-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "X-----X-----#"
        ]

        self.assertEqual(
            my_game.get_two_adjacent_pieces_for_player('player1'), num_rows)

        game_board = [
            "#-----#-----#",
            "|-    |    -|",
            "| #---O---O |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "#-#-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| X---#---# |",
            "|-    |    -|",
            "X-----X-----#"
        ]

        self.assertEqual(
            my_game.get_two_adjacent_pieces_for_player('player1'), num_rows)

    def test_available_actions_phase_2(self):
        """
        check the positions where you can place on or move to a piece
        """
        game_board = [
            "X-----X-----#",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "O-#-#   #-#-X",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "O-----#-----X"
        ]
        my_game = game(50, self.parse_game_board_text(game_board), 'player1')
        result = [
            {'from': [0, 0], 'to': [2, 2]},
            {'from': [0, 6], 'to': [0, 12], 'remove': [2, 6]},
            {'from': [0, 6], 'to': [0, 12], 'remove': [6, 0]},
            {'from': [0, 6], 'to': [0, 12], 'remove': [12, 0]},
            {'from': [6, 12], 'to': [0, 12], 'remove': [2, 6]},
            {'from': [6, 12], 'to': [0, 12], 'remove': [6, 0]},
            {'from': [6, 12], 'to': [0, 12], 'remove': [12, 0]},
            {'from': [6, 12], 'to': [6, 10]},
            {'from': [12, 12], 'to': [12, 6]},
            {'from': [12, 12], 'to': [10, 10]}
        ]

        self.assertEqual(my_game.get_available_actions('player1'), result)

    def test_available_actions_phase_2_prioritize_no_rows(self):
        """
        check the positions where you can take peices (don't take rows if possible)
        """
        game_board = [
            "X-----X-----#",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "O-#-#   #-#-X",
            "| | |   | | |",
            "| | O-#-# | |",
            "| |-  |  -| |",
            "| O---#---# |",
            "|-    |    -|",
            "O-----#-----X"
        ]
        my_game = game(50, self.parse_game_board_text(game_board), 'player1')
        result = [
            {'from': [0, 0], 'to': [2, 2]},
            {'from': [0, 6], 'to': [0, 12], 'remove': [2, 6]},
            {'from': [0, 6], 'to': [0, 12], 'remove': [6, 0]},
            {'from': [6, 12], 'to': [0, 12], 'remove': [2, 6]},
            {'from': [6, 12], 'to': [0, 12], 'remove': [6, 0]},
            {'from': [6, 12], 'to': [6, 10]},
            {'from': [12, 12], 'to': [12, 6]},
            {'from': [12, 12], 'to': [10, 10]}
        ]

        self.assertEqual(my_game.get_available_actions('player1'), result)

    def test_available_actions_phase_2_prioritize_only_rows_available(self):
        """
        check the positions where you can take peices (don't take rows if
        possible), rows only available
        """
        game_board = [
            "X-----X-----#",
            "|-    |    -|",
            "| #---#---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "O-O-O   #-#-X",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "#-----#-----X"
        ]
        my_game = game(50, self.parse_game_board_text(game_board), 'player1')
        result = [
            {'from': [0, 0], 'to': [2, 2]},
            {'from': [0, 6], 'to': [2, 6]},
            {'from': [0, 6], 'to': [0, 12], 'remove': [6, 0]},
            {'from': [0, 6], 'to': [0, 12], 'remove': [6, 2]},
            {'from': [0, 6], 'to': [0, 12], 'remove': [6, 4]},
            {'from': [6, 12], 'to': [0, 12], 'remove': [6, 0]},
            {'from': [6, 12], 'to': [0, 12], 'remove': [6, 2]},
            {'from': [6, 12], 'to': [0, 12], 'remove': [6, 4]},
            {'from': [6, 12], 'to': [6, 10]},
            {'from': [12, 12], 'to': [12, 6]},
            {'from': [12, 12], 'to': [10, 10]}
        ]

        self.assertEqual(my_game.get_available_actions('player1'), result)

    def test_available_actions_phase_2_invalid_prev_move(self):
        """
        a piece can't move back to a previous position that it used to form a
        row if the last move formed a row 
        """
        my_file_parser = file_parser(
            'tests/game_file_examples/phase_2_invalid_prev_move.json')
        my_game = game(
            turn=my_file_parser.get_turn(),
            game_board=my_file_parser.get_game_board(),
            curr_player=my_file_parser.get_player_to_move(),
            last_action=my_file_parser.get_last_action_for_player(
                my_file_parser.get_player_to_move()),
        )
        result = [
            {'from': [8, 8], 'to': [6, 8]},
            {'from': [8, 6], 'to': [8, 4]},
            {'from': [10, 2], 'to': [6, 2]},
            {'from': [10, 2], 'to': [8, 4], 'remove': [6, 0]},
            {'from': [10, 2], 'to': [8, 4], 'remove': [6, 4]},
            {'from': [10, 2], 'to': [8, 4], 'remove': [6, 12]},
            {'from': [10, 10], 'to': [6, 10]},
            {'from': [12, 6], 'to': [12, 0]},
        ]

        self.assertCountEqual(my_game.get_available_actions('player1'), result)

    def test_available_moves_phase_1(self):
        """
        check the positions where you can place on or move to a piece
        in phase 1
        """
        game_board = [
            "#-----#-----X",
            "|-    |    -|",
            "| O---#---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "#-#-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "#-----#-----#"
        ]
        my_game = game(2, self.parse_game_board_text(game_board), 'player1')
        result = [
            [0, 0], [0, 6], [2, 6], [2, 10], [4, 4], [4, 6],
            [4, 8], [6, 0], [6, 2], [6, 4], [
                6, 8], [6, 10], [6, 12], [8, 4],
            [8, 6], [8, 8], [10, 2], [10, 6], [10, 10], [12, 0], [12, 6], [12, 12]]
        result = [{'to': x} for x in result]

        self.assertEqual(my_game.get_available_actions('player1'), result)

    def test_middle_positions(self):
        """
        check number of middle peices for a player
        """
        game_board = [
            "X-----O-----#",
            "|-    |    -|",
            "| X---#---# |",
            "| |-  |  -| |",
            "| | #-#-O | |",
            "| | |   | | |",
            "#-#-X   #-O-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| X---#---X |",
            "|-    |    -|",
            "#-----#-----#"
        ]
        my_game = game(50, self.parse_game_board_text(game_board), 'player1')
        num_pieces = 3
        self.assertEqual(
            my_game.get_middle_pieces_for_player('player1'), num_pieces)

    def test_formed_rows_from_action(self):
        """
        check num of formed rows depending on last action
        """
        game_board = [
            "#-----#-----X",
            "|-    |    -|",
            "| O---#---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "#-#-#   #-X-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "#-----#-----X"
        ]
        my_game = game(2, self.parse_game_board_text(game_board), 'player1')
        action = {
            'to': [6, 12]
        }

        num_rows = 1

        self.assertEqual(
            my_game.get_formed_rows_from_action(action), num_rows)

    def test_formed_diagonal_rows_from_action(self):
        """
        check num of formed rows depending on last action
        """
        game_board = [
            "#-----#-----X",
            "|-    |    -|",
            "| O---#---# |",
            "| |-  |  -| |",
            "| | #-#-X | |",
            "| | |   | | |",
            "#-#-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "#-----#-----#"
        ]
        my_game = game(2, self.parse_game_board_text(game_board), 'player1')
        action = {
            'to': [2, 10]
        }

        num_rows = 1

        self.assertEqual(
            my_game.get_formed_rows_from_action(action), num_rows)

    def test_formed_rows_for_player(self):
        """
        check num of formed rows for a player
        """
        game_board = [
            "O-----#-----X",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "O-#-#   X-X-X",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---#---# |",
            "|-    |    -|",
            "X-----X-----X"
        ]
        my_game = game(50, self.parse_game_board_text(game_board), 'player1')
        num_rows = 3
        self.assertEqual(
            len(my_game.get_formed_rows_for_player('player1')) / 3, num_rows)

    def test_formed_rows_for_player_diagonal(self):
        """
        check num of formed rows for a player diagonally
        """
        game_board = [
            "O-----#-----X",
            "|-    |    -|",
            "| #---O---X |",
            "| |-  |  -| |",
            "| | #-#-X | |",
            "| | |   | | |",
            "O-#-#   #-X-#",
            "| | |   | | |",
            "| | #-X-X | |",
            "| |-  |  -| |",
            "| #---X---X |",
            "|-    |    -|",
            "#-----#-----X"
        ]
        my_game = game(50, self.parse_game_board_text(game_board), 'player1')
        num_rows = 3
        self.assertEqual(
            len(my_game.get_formed_rows_for_player('player1')) / 3, num_rows)

    def test_available_moves_phase_3(self):
        """
        check the moves for phase 3
        """
        game_board = [
            "O-----#-----#",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "O-#-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---X---# |",
            "|-    |    -|",
            "X-----#-----X"
        ]
        my_game = game(50, self.parse_game_board_text(game_board), 'player1')
        available_positions = [
            [0, 6],
            [0, 12], [2, 2], [2, 10], [4, 4], [4, 6],
            [4, 8], [6, 2], [6, 4], [6, 8],
            [6, 10], [6, 12], [8, 4], [8, 6],
            [8, 8], [10, 2], [10, 10], [12, 6]]
        result = [
            {'from': [10, 6], 'to': available_positions},
            {'from': [12, 0], 'to': available_positions},
            {'from': [12, 12], 'to': available_positions}]

        self.assertEqual(my_game.get_available_moves('player1'), result)

    def test_game_action_place_peice(self):
        """
        check game actions
        """
        game_board = [
            "O-----#-----#",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "O-#-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---X---# |",
            "|-    |    -|",
            "X-----#-----X"
        ]
        my_game = game(10, self.parse_game_board_text(game_board), 'player1')
        action = {'to': [0, 6]}
        result = [
            "O-----X-----#",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "O-#-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---X---# |",
            "|-    |    -|",
            "X-----#-----X"
        ]

        my_game.make_action(action)
        self.assertEqual(my_game.get_game_board(),
                         self.parse_game_board_text(result))

    def test_game_action_move_peice(self):
        """
        check game actions
        """
        game_board = [
            "O-----#-----#",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "O-#-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---X---# |",
            "|-    |    -|",
            "X-----#-----X"
        ]
        my_game = game(40, self.parse_game_board_text(game_board), 'player1')
        action = {
            'from': [12, 12],
            'to': [0, 12],
        }

        result = [
            "O-----#-----X",
            "|-    |    -|",
            "| #---O---# |",
            "| |-  |  -| |",
            "| | #-#-# | |",
            "| | |   | | |",
            "O-#-#   #-#-#",
            "| | |   | | |",
            "| | #-#-# | |",
            "| |-  |  -| |",
            "| #---X---# |",
            "|-    |    -|",
            "X-----#-----#"
        ]

        my_game.make_action(action)
        self.assertEqual(my_game.get_game_board(),
                         self.parse_game_board_text(result))

        if __name__ == '__main__':
            unittest.main()
